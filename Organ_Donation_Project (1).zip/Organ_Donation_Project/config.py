# Organ Transplant Database Configuration

# Database settings
DATABASE_URL = "sqlite:///./organ_transplant.db"

# API settings
API_HOST = "0.0.0.0"
API_PORT = 8000
API_TITLE = "Organ Transplant Database & Hospital Locator"
API_VERSION = "1.0.0"

# Frontend settings
FRONTEND_PORT = 8001
FRONTEND_HOST = "localhost"

# Security settings
SECRET_KEY = "your-secret-key-here"
DEBUG = True

# Logging settings
LOG_LEVEL = "INFO"
LOG_FILE = "logs/system.log"

# Map settings
DEFAULT_MAP_CENTER_LAT = 20.5937
DEFAULT_MAP_CENTER_LON = 78.9629
DEFAULT_MAP_ZOOM = 5

# Search settings
MAX_SEARCH_DISTANCE_KM = 1000
DEFAULT_SEARCH_DISTANCE_KM = 500
