# 🚀 Quick Start Guide - Organ Donation Project

## ⚡ 5-Minute Setup

### Step 1: Download & Extract
1. Download the `Organ_Donation_Project` folder
2. Extract to your desired location
3. Open terminal/command prompt in the folder

### Step 2: Run Setup (One Command)
```bash
python setup.py
```
*This will install everything automatically!*

### Step 3: Start the System
```bash
python run_system.py
```

### Step 4: Open Your Browser
- **Main Interface**: http://localhost:8001
- **API Documentation**: http://localhost:8000/docs

## 🎯 What You Can Do Immediately

### 1. **Search for Organs**
- Click "Search for Organs" 
- Select organ type (Heart, Liver, Kidney, etc.)
- Choose blood type and urgency level
- Click "Search Organs"
- View results on the map!

### 2. **Find Nearest Hospitals**
- Click "Find Nearest Hospitals"
- Set maximum distance
- Click "Find Hospitals"
- See all nearby transplant centers

### 3. **Submit Patient Request**
- Fill out the patient request form
- Enter patient details and required organ
- Submit the request
- Get matched with compatible hospitals

### 4. **Use the Interactive Map**
- Zoom in/out to explore
- Click hospital markers for details
- Get directions to any hospital
- View real-time organ availability

## 🏥 Sample Data Included

The system comes pre-loaded with:
- **8 Major Hospitals** across India
- **7 Organ Types** (Heart, Liver, Kidney, Lung, Pancreas, Cornea, Bone Marrow)
- **Realistic Availability Data** with blood types and conditions
- **Sample Patient Requests** for testing

## 🔧 System Features

### ✅ **Complete Organ Database**
- Hospital registry with contact details
- Organ availability tracking
- Blood type compatibility
- Quality assessment

### ✅ **GPS Navigation**
- Real-time location detection
- Distance calculations
- Route optimization
- Turn-by-turn directions

### ✅ **Smart Search**
- Filter by organ type, blood type, urgency
- Distance-based results
- Compatibility scoring
- Priority ranking

### ✅ **Interactive Map**
- Hospital location markers
- Real-time updates
- Mobile responsive
- Easy navigation

## 📱 How to Use

### For Patients/Families
1. **Allow Location Access** when prompted
2. **Search for Organs** by type and location
3. **View Hospital Details** on the map
4. **Get Directions** to compatible hospitals
5. **Submit Requests** for organ matching

### For Healthcare Workers
1. **View All Hospitals** in the system
2. **Check Organ Availability** in real-time
3. **Update Patient Status** as needed
4. **Access Contact Information** for coordination

### For Administrators
1. **Monitor System Statistics** via API
2. **Add New Hospitals** to the database
3. **Update Organ Availability** as needed
4. **Track Patient Requests** and outcomes

## 🎮 Demo Scenarios

### Scenario 1: Emergency Heart Transplant
1. Search for "Heart" organs
2. Set urgency to "Critical (4)"
3. View nearest available hearts
4. Get emergency directions

### Scenario 2: Routine Kidney Search
1. Search for "Kidney" organs
2. Filter by blood type "O+"
3. Set reasonable distance (100km)
4. Compare multiple options

### Scenario 3: Hospital Research
1. Find all hospitals within 50km
2. Check available organs at each
3. Compare contact information
4. Plan visit routes

## 🛠️ Troubleshooting

### If the system won't start:
```bash
# Check Python version
python --version

# Install missing packages
pip install -r requirements.txt

# Run tests
python test_system.py
```

### If the map doesn't load:
- Check internet connection
- Allow location access in browser
- Try refreshing the page
- Check browser console for errors

### If search returns no results:
- Try increasing the distance range
- Check if backend is running (port 8000)
- Verify database has sample data
- Run the setup script again

## 📞 Getting Help

### Quick Fixes
1. **Restart the system**: Stop and run `python run_system.py` again
2. **Check ports**: Ensure 8000 and 8001 are available
3. **Update browser**: Use latest Chrome, Firefox, or Edge
4. **Clear cache**: Refresh browser with Ctrl+F5

### System Status
- **Backend Running**: http://localhost:8000/health
- **Frontend Running**: http://localhost:8001
- **API Working**: http://localhost:8000/docs

## 🎉 Success Indicators

You'll know the system is working when:
- ✅ Backend shows "System is running..."
- ✅ Frontend loads with map interface
- ✅ Location access is granted
- ✅ Hospital markers appear on map
- ✅ Search returns results
- ✅ Directions work properly

## 🚀 Next Steps

After getting familiar with the system:
1. **Explore the API** at http://localhost:8000/docs
2. **Read the full documentation** in README.md
3. **Check system features** in FEATURES.md
4. **Run comprehensive tests** with `python test_system.py`
5. **Customize the system** for your needs

---

**Ready to save lives with technology! 🫀❤️**

*The system is now running and ready to help patients find life-saving organs!*
