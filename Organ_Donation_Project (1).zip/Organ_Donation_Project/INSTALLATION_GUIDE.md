# 🏥 Organ Donation Project - Installation Guide

## Quick Start (Windows)

### Step 1: Install Python
- Download Python 3.8+ from https://python.org
- Make sure to check "Add Python to PATH" during installation

### Step 2: Run Setup
```bash
# Open Command Prompt or PowerShell in the project folder
cd Organ_Donation_Project
python setup.py
```

### Step 3: Start the System
```bash
# Option 1: Double-click start_system.bat
# Option 2: Run in terminal
python run_system.py
```

### Step 4: Open in Browser
- Frontend: http://localhost:8001
- API Documentation: http://localhost:8000/docs

## Quick Start (Mac/Linux)

### Step 1: Install Python
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install python3 python3-pip

# macOS
brew install python3
```

### Step 2: Run Setup
```bash
cd Organ_Donation_Project
python3 setup.py
```

### Step 3: Start the System
```bash
# Option 1: Run shell script
./start_system.sh

# Option 2: Run directly
python3 run_system.py
```

## Manual Installation

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Initialize Database
```bash
python database.py
```

### 3. Start Backend
```bash
python main.py
```

### 4. Start Frontend
```bash
# In another terminal
cd frontend
python -m http.server 8001
```

## Troubleshooting

### Common Issues

**Issue: "Module not found" error**
```bash
# Solution: Install missing packages
pip install fastapi uvicorn sqlalchemy pandas requests
```

**Issue: "Port already in use"**
```bash
# Solution: Kill processes using the ports
# Windows
netstat -ano | findstr :8000
taskkill /PID <PID_NUMBER> /F

# Mac/Linux
lsof -ti:8000 | xargs kill -9
```

**Issue: Database errors**
```bash
# Solution: Delete and recreate database
rm organ_transplant.db
python database.py
```

**Issue: Frontend not loading**
- Check if backend is running on port 8000
- Check browser console for errors
- Ensure all files are in the correct directories

### System Requirements
- Python 3.8 or higher
- 2GB RAM minimum
- 100MB disk space
- Modern web browser (Chrome, Firefox, Safari, Edge)

### Supported Operating Systems
- Windows 10/11
- macOS 10.14+
- Ubuntu 18.04+
- CentOS 7+

## Features Included

✅ **Complete Organ Database System**
- Hospital management
- Organ availability tracking
- Patient request system

✅ **Interactive Map Interface**
- Hospital location markers
- GPS navigation
- Distance calculations

✅ **Advanced Search**
- Organ type filtering
- Blood type compatibility
- Urgency level matching

✅ **GPS Routing**
- Real-time navigation
- Emergency routing
- Multiple transport modes

✅ **Patient Management**
- Request submission
- Status tracking
- Hospital matching

## Support

If you encounter any issues:
1. Check the README.md file
2. Run the test suite: `python test_system.py`
3. Check the logs in the `logs/` directory
4. Verify all dependencies are installed

## Next Steps

After successful installation:
1. Open http://localhost:8001 in your browser
2. Allow location access when prompted
3. Try searching for organs or hospitals
4. Submit a test patient request
5. Explore the interactive map features

**Happy Organ Matching! 🫀❤️**
