#!/usr/bin/env python3
"""
Setup script for the Organ Transplant Database & Hospital Locator System
"""

import os
import sys
import subprocess
import platform
from pathlib import Path

def print_banner():
    """Print setup banner"""
    banner = """
    ╔══════════════════════════════════════════════════════════════╗
    ║                                                              ║
    ║        🏥 ORGAN TRANSPLANT DATABASE & HOSPITAL LOCATOR 🏥     ║
    ║                                                              ║
    ║                    Setup & Installation                      ║
    ║                                                              ║
    ╚══════════════════════════════════════════════════════════════╝
    """
    print(banner)

def check_python_version():
    """Check if Python version is compatible"""
    print("🐍 Checking Python version...")
    
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required")
        print(f"   Current version: {sys.version}")
        return False
    
    print(f"✅ Python {sys.version.split()[0]} is compatible")
    return True

def install_dependencies():
    """Install required Python packages"""
    print("\n📦 Installing dependencies...")
    
    requirements_file = Path(__file__).parent / "requirements.txt"
    
    if not requirements_file.exists():
        print("❌ requirements.txt not found")
        return False
    
    try:
        subprocess.check_call([
            sys.executable, "-m", "pip", "install", "-r", str(requirements_file)
        ])
        print("✅ Dependencies installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install dependencies: {e}")
        return False

def create_directories():
    """Create necessary directories"""
    print("\n📁 Creating directories...")
    
    directories = [
        "frontend",
        "logs",
        "data"
    ]
    
    for directory in directories:
        dir_path = Path(__file__).parent / directory
        dir_path.mkdir(exist_ok=True)
        print(f"✅ Created directory: {directory}")
    
    return True

def setup_database():
    """Initialize the database"""
    print("\n🗄️  Setting up database...")
    
    try:
        from database import create_tables, init_sample_data
        create_tables()
        init_sample_data()
        print("✅ Database initialized successfully")
        return True
    except Exception as e:
        print(f"❌ Database setup failed: {e}")
        return False

def create_startup_scripts():
    """Create startup scripts for different platforms"""
    print("\n🚀 Creating startup scripts...")
    
    # Windows batch file
    windows_script = """@echo off
echo Starting Organ Transplant Database System...
python run_system.py
pause
"""
    
    # Unix shell script
    unix_script = """#!/bin/bash
echo "Starting Organ Transplant Database System..."
python3 run_system.py
"""
    
    # Create scripts
    with open("start_system.bat", "w") as f:
        f.write(windows_script)
    
    with open("start_system.sh", "w") as f:
        f.write(unix_script)
    
    # Make Unix script executable
    if platform.system() != "Windows":
        os.chmod("start_system.sh", 0o755)
    
    print("✅ Startup scripts created")
    return True

def create_config_file():
    """Create configuration file"""
    print("\n⚙️  Creating configuration file...")
    
    config = """# Organ Transplant Database Configuration

# Database settings
DATABASE_URL = "sqlite:///./organ_transplant.db"

# API settings
API_HOST = "0.0.0.0"
API_PORT = 8000
API_TITLE = "Organ Transplant Database & Hospital Locator"
API_VERSION = "1.0.0"

# Frontend settings
FRONTEND_PORT = 8001
FRONTEND_HOST = "localhost"

# Security settings
SECRET_KEY = "your-secret-key-here"
DEBUG = True

# Logging settings
LOG_LEVEL = "INFO"
LOG_FILE = "logs/system.log"

# Map settings
DEFAULT_MAP_CENTER_LAT = 20.5937
DEFAULT_MAP_CENTER_LON = 78.9629
DEFAULT_MAP_ZOOM = 5

# Search settings
MAX_SEARCH_DISTANCE_KM = 1000
DEFAULT_SEARCH_DISTANCE_KM = 500
"""
    
    with open("config.py", "w") as f:
        f.write(config)
    
    print("✅ Configuration file created")
    return True

def run_tests():
    """Run system tests"""
    print("\n🧪 Running system tests...")
    
    try:
        result = subprocess.run([
            sys.executable, "test_system.py"
        ], capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            print("✅ All tests passed")
            return True
        else:
            print("⚠️  Some tests failed")
            print("STDOUT:", result.stdout)
            print("STDERR:", result.stderr)
            return False
    except subprocess.TimeoutExpired:
        print("⏰ Tests timed out")
        return False
    except Exception as e:
        print(f"❌ Test execution failed: {e}")
        return False

def print_completion_message():
    """Print setup completion message"""
    print("\n" + "="*60)
    print("🎉 SETUP COMPLETED SUCCESSFULLY!")
    print("="*60)
    
    print("\n📋 Next Steps:")
    print("   1. Start the system:")
    print("      • Windows: double-click start_system.bat")
    print("      • Unix/Mac: ./start_system.sh")
    print("      • Or run: python run_system.py")
    
    print("\n   2. Open your browser:")
    print("      • Frontend: http://localhost:8001")
    print("      • API Docs: http://localhost:8000/docs")
    
    print("\n🔧 System Features:")
    print("   • Search for organs by type and location")
    print("   • Find nearest hospitals with transplant services")
    print("   • GPS navigation and routing")
    print("   • Patient request submission")
    print("   • Interactive map with hospital markers")
    
    print("\n📚 Documentation:")
    print("   • README.md - Complete system documentation")
    print("   • API Docs - http://localhost:8000/docs")
    print("   • Test Suite - python test_system.py")
    
    print("\n🆘 Support:")
    print("   • Check logs/ directory for error logs")
    print("   • Run tests to verify system functionality")
    print("   • Check README.md for troubleshooting")
    
    print("\n" + "="*60)

def main():
    """Main setup function"""
    print_banner()
    
    # Check Python version
    if not check_python_version():
        sys.exit(1)
    
    # Install dependencies
    if not install_dependencies():
        print("\n❌ Setup failed at dependency installation")
        sys.exit(1)
    
    # Create directories
    if not create_directories():
        print("\n❌ Setup failed at directory creation")
        sys.exit(1)
    
    # Setup database
    if not setup_database():
        print("\n❌ Setup failed at database initialization")
        sys.exit(1)
    
    # Create startup scripts
    if not create_startup_scripts():
        print("\n❌ Setup failed at startup script creation")
        sys.exit(1)
    
    # Create config file
    if not create_config_file():
        print("\n❌ Setup failed at configuration creation")
        sys.exit(1)
    
    # Run tests (optional)
    print("\n🧪 Running system tests...")
    test_success = run_tests()
    
    if test_success:
        print("✅ All tests passed!")
    else:
        print("⚠️  Some tests failed, but system may still work")
    
    # Print completion message
    print_completion_message()

if __name__ == "__main__":
    main()

