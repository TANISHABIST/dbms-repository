from fastapi import FastAPI, HTTPException, Depends, Query, Body
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
import uvicorn
from datetime import datetime

# Import our modules
from database import get_db, create_tables, init_sample_data
from models import Hospital, Organ, OrganAvailability, PatientRequest
from search_service import OrganSearchService
from geolocation import GeolocationService

# Create FastAPI app
app = FastAPI(
    title="Organ Transplant Database & Hospital Locator",
    description="A comprehensive system for finding organ transplant services and nearest hospitals",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize database
create_tables()
init_sample_data()

@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "message": "Organ Transplant Database & Hospital Locator API",
        "version": "1.0.0",
        "endpoints": {
            "hospitals": "/hospitals",
            "organs": "/organs",
            "search": "/search/organs",
            "nearest": "/search/nearest-hospitals",
            "patient-request": "/patient-request"
        }
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": datetime.utcnow().isoformat()}

# Hospital endpoints
@app.get("/hospitals", response_model=List[Dict[str, Any]])
async def get_hospitals(
    city: Optional[str] = Query(None, description="Filter by city"),
    state: Optional[str] = Query(None, description="Filter by state"),
    limit: int = Query(100, description="Maximum number of hospitals to return"),
    db: Session = Depends(get_db)
):
    """Get list of hospitals with optional filtering"""
    query = db.query(Hospital)
    
    if city:
        query = query.filter(Hospital.city.ilike(f"%{city}%"))
    if state:
        query = query.filter(Hospital.state.ilike(f"%{state}%"))
    
    hospitals = query.limit(limit).all()
    
    return [
        {
            "id": hospital.id,
            "name": hospital.name,
            "address": hospital.address,
            "city": hospital.city,
            "state": hospital.state,
            "country": hospital.country,
            "latitude": hospital.latitude,
            "longitude": hospital.longitude,
            "phone": hospital.phone,
            "email": hospital.email,
            "website": hospital.website,
            "is_transplant_center": hospital.is_transplant_center
        }
        for hospital in hospitals
    ]

@app.get("/hospitals/{hospital_id}", response_model=Dict[str, Any])
async def get_hospital(hospital_id: int, db: Session = Depends(get_db)):
    """Get specific hospital details"""
    hospital = db.query(Hospital).filter(Hospital.id == hospital_id).first()
    if not hospital:
        raise HTTPException(status_code=404, detail="Hospital not found")
    
    return {
        "id": hospital.id,
        "name": hospital.name,
        "address": hospital.address,
        "city": hospital.city,
        "state": hospital.state,
        "country": hospital.country,
        "latitude": hospital.latitude,
        "longitude": hospital.longitude,
        "phone": hospital.phone,
        "email": hospital.email,
        "website": hospital.website,
        "is_transplant_center": hospital.is_transplant_center,
        "created_at": hospital.created_at.isoformat()
    }

# Organ endpoints
@app.get("/organs", response_model=List[Dict[str, Any]])
async def get_organs(db: Session = Depends(get_db)):
    """Get list of all available organs"""
    organs = db.query(Organ).all()
    
    return [
        {
            "id": organ.id,
            "name": organ.name,
            "description": organ.description,
            "urgency_level": organ.urgency_level,
            "preservation_time_hours": organ.preservation_time_hours
        }
        for organ in organs
    ]

@app.get("/organs/{organ_id}", response_model=Dict[str, Any])
async def get_organ(organ_id: int, db: Session = Depends(get_db)):
    """Get specific organ details"""
    organ = db.query(Organ).filter(Organ.id == organ_id).first()
    if not organ:
        raise HTTPException(status_code=404, detail="Organ not found")
    
    return {
        "id": organ.id,
        "name": organ.name,
        "description": organ.description,
        "urgency_level": organ.urgency_level,
        "preservation_time_hours": organ.preservation_time_hours
    }

# Search endpoints
@app.get("/search/organs", response_model=List[Dict[str, Any]])
async def search_organs(
    latitude: float = Query(..., description="User latitude"),
    longitude: float = Query(..., description="User longitude"),
    organ_name: Optional[str] = Query(None, description="Name of organ to search for"),
    blood_type: Optional[str] = Query(None, description="Blood type filter"),
    max_distance_km: float = Query(500.0, description="Maximum distance in kilometers"),
    urgency_level: Optional[int] = Query(None, description="Minimum urgency level (1-4)"),
    db: Session = Depends(get_db)
):
    """Search for available organs near user location"""
    search_service = OrganSearchService(db)
    
    results = search_service.search_organs_by_location(
        user_latitude=latitude,
        user_longitude=longitude,
        organ_name=organ_name,
        blood_type=blood_type,
        max_distance_km=max_distance_km,
        urgency_level=urgency_level
    )
    
    return results

@app.get("/search/nearest-hospitals", response_model=List[Dict[str, Any]])
async def get_nearest_hospitals(
    latitude: float = Query(..., description="User latitude"),
    longitude: float = Query(..., description="User longitude"),
    max_distance_km: float = Query(100.0, description="Maximum distance in kilometers"),
    db: Session = Depends(get_db)
):
    """Find nearest hospitals to user location"""
    search_service = OrganSearchService(db)
    
    results = search_service.find_nearest_hospitals(
        user_latitude=latitude,
        user_longitude=longitude,
        max_distance_km=max_distance_km
    )
    
    return results

@app.get("/hospitals/{hospital_id}/organs", response_model=Dict[str, Any])
async def get_hospital_organs(
    hospital_id: int,
    db: Session = Depends(get_db)
):
    """Get all available organs at a specific hospital"""
    search_service = OrganSearchService(db)
    
    result = search_service.get_hospital_organ_availability(hospital_id)
    
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    
    return result

# Patient request endpoints
@app.post("/patient-request", response_model=Dict[str, Any])
async def create_patient_request(
    patient_name: str = Body(..., description="Patient name"),
    patient_age: int = Body(..., description="Patient age"),
    blood_type: str = Body(..., description="Patient blood type"),
    organ_name: str = Body(..., description="Required organ name"),
    latitude: float = Body(..., description="Patient location latitude"),
    longitude: float = Body(..., description="Patient location longitude"),
    contact_phone: Optional[str] = Body(None, description="Contact phone number"),
    contact_email: Optional[str] = Body(None, description="Contact email"),
    medical_notes: Optional[str] = Body(None, description="Medical notes"),
    urgency_level: int = Body(1, description="Urgency level (1-4)"),
    db: Session = Depends(get_db)
):
    """Create a new patient request for organ transplant"""
    search_service = OrganSearchService(db)
    
    result = search_service.create_patient_request(
        patient_name=patient_name,
        patient_age=patient_age,
        blood_type=blood_type,
        organ_name=organ_name,
        user_latitude=latitude,
        user_longitude=longitude,
        contact_phone=contact_phone,
        contact_email=contact_email,
        medical_notes=medical_notes,
        urgency_level=urgency_level
    )
    
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    
    return result

@app.get("/patient-requests", response_model=List[Dict[str, Any]])
async def get_patient_requests(
    status: Optional[str] = Query(None, description="Filter by status"),
    limit: int = Query(50, description="Maximum number of requests to return"),
    db: Session = Depends(get_db)
):
    """Get list of patient requests"""
    query = db.query(PatientRequest)
    
    if status:
        query = query.filter(PatientRequest.status == status)
    
    requests = query.limit(limit).all()
    
    return [
        {
            "id": request.id,
            "patient_name": request.patient_name,
            "patient_age": request.patient_age,
            "blood_type": request.blood_type,
            "organ_name": request.organ.name if request.organ else "Unknown",
            "urgency_level": request.urgency_level,
            "location": {
                "latitude": request.location_latitude,
                "longitude": request.location_longitude
            },
            "contact_phone": request.contact_phone,
            "contact_email": request.contact_email,
            "medical_notes": request.medical_notes,
            "status": request.status,
            "created_at": request.created_at.isoformat()
        }
        for request in requests
    ]

# Statistics endpoints
@app.get("/stats", response_model=Dict[str, Any])
async def get_statistics(db: Session = Depends(get_db)):
    """Get system statistics"""
    total_hospitals = db.query(Hospital).count()
    total_organs = db.query(Organ).count()
    available_organs = db.query(OrganAvailability).filter(
        OrganAvailability.is_available == True
    ).count()
    total_requests = db.query(PatientRequest).count()
    pending_requests = db.query(PatientRequest).filter(
        PatientRequest.status == "pending"
    ).count()
    
    return {
        "total_hospitals": total_hospitals,
        "total_organs": total_organs,
        "available_organs": available_organs,
        "total_requests": total_requests,
        "pending_requests": pending_requests,
        "timestamp": datetime.utcnow().isoformat()
    }

# Distance calculation endpoint
@app.get("/calculate-distance", response_model=Dict[str, Any])
async def calculate_distance(
    lat1: float = Query(..., description="First location latitude"),
    lon1: float = Query(..., description="First location longitude"),
    lat2: float = Query(..., description="Second location latitude"),
    lon2: float = Query(..., description="Second location longitude")
):
    """Calculate distance between two coordinates"""
    geo_service = GeolocationService()
    
    from geolocation import Location
    location1 = Location(lat1, lon1)
    location2 = Location(lat2, lon2)
    
    distance_result = geo_service.calculate_distance(location1, location2)
    
    return {
        "distance_km": round(distance_result.distance_km, 2),
        "distance_miles": round(distance_result.distance_miles, 2),
        "estimated_travel_time_minutes": distance_result.estimated_travel_time_minutes
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)

