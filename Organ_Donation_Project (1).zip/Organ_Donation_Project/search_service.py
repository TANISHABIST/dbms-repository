from typing import List, Dict, Optional, Tuple
from sqlalchemy.orm import Session
from models import Hospital, Organ, OrganAvailability, PatientRequest, SearchResult
from geolocation import GeolocationService, Location, DistanceResult
from datetime import datetime
import json

class OrganSearchService:
    """Advanced search service for finding organs and hospitals"""
    
    def __init__(self, db_session: Session):
        self.db = db_session
        self.geo_service = GeolocationService()
    
    def search_organs_by_location(self, 
                                user_latitude: float, 
                                user_longitude: float, 
                                organ_name: str,
                                blood_type: str = None,
                                max_distance_km: float = 500.0,
                                urgency_level: int = None) -> List[Dict]:
        """
        Search for available organs near user location
        """
        # Get all hospitals with available organs
        query = self.db.query(OrganAvailability).join(Hospital).join(Organ)
        
        # Filter by organ name
        if organ_name:
            query = query.filter(Organ.name.ilike(f"%{organ_name}%"))
        
        # Filter by blood type if provided
        if blood_type:
            query = query.filter(OrganAvailability.blood_type == blood_type)
        
        # Filter by urgency level
        if urgency_level:
            query = query.filter(Organ.urgency_level <= urgency_level)
        
        # Filter by availability
        query = query.filter(OrganAvailability.is_available == True)
        
        organ_availabilities = query.all()
        
        # Calculate distances and create results
        results = []
        user_location = Location(user_latitude, user_longitude)
        
        for availability in organ_availabilities:
            hospital_location = Location(
                availability.hospital.latitude, 
                availability.hospital.longitude
            )
            
            distance_result = self.geo_service.calculate_distance(
                user_location, hospital_location
            )
            
            # Skip if too far
            if distance_result.distance_km > max_distance_km:
                continue
            
            # Calculate compatibility score
            compatibility_score = self._calculate_compatibility_score(
                availability, blood_type, urgency_level
            )
            
            result = {
                "hospital": {
                    "id": availability.hospital.id,
                    "name": availability.hospital.name,
                    "address": availability.hospital.address,
                    "city": availability.hospital.city,
                    "state": availability.hospital.state,
                    "phone": availability.hospital.phone,
                    "email": availability.hospital.email,
                    "website": availability.hospital.website,
                    "latitude": availability.hospital.latitude,
                    "longitude": availability.hospital.longitude
                },
                "organ": {
                    "id": availability.organ.id,
                    "name": availability.organ.name,
                    "description": availability.organ.description,
                    "urgency_level": availability.organ.urgency_level,
                    "preservation_time_hours": availability.organ.preservation_time_hours
                },
                "availability": {
                    "id": availability.id,
                    "quantity": availability.quantity,
                    "blood_type": availability.blood_type,
                    "age_range": availability.age_range,
                    "condition": availability.condition,
                    "notes": availability.notes,
                    "last_updated": availability.last_updated.isoformat()
                },
                "distance": {
                    "km": round(distance_result.distance_km, 2),
                    "miles": round(distance_result.distance_miles, 2),
                    "travel_time_minutes": distance_result.estimated_travel_time_minutes
                },
                "compatibility_score": round(compatibility_score, 2),
                "priority_score": self._calculate_priority_score(
                    distance_result.distance_km, 
                    compatibility_score, 
                    availability.organ.urgency_level
                )
            }
            
            results.append(result)
        
        # Sort by priority score (higher is better)
        results.sort(key=lambda x: x["priority_score"], reverse=True)
        
        return results
    
    def find_nearest_hospitals(self, 
                             user_latitude: float, 
                             user_longitude: float, 
                             max_distance_km: float = 100.0) -> List[Dict]:
        """
        Find nearest hospitals regardless of organ availability
        """
        hospitals = self.db.query(Hospital).filter(
            Hospital.is_transplant_center == True
        ).all()
        
        user_location = Location(user_latitude, user_longitude)
        nearby_hospitals = []
        
        for hospital in hospitals:
            hospital_location = Location(hospital.latitude, hospital.longitude)
            distance_result = self.geo_service.calculate_distance(
                user_location, hospital_location
            )
            
            if distance_result.distance_km <= max_distance_km:
                hospital_info = {
                    "id": hospital.id,
                    "name": hospital.name,
                    "address": hospital.address,
                    "city": hospital.city,
                    "state": hospital.state,
                    "phone": hospital.phone,
                    "email": hospital.email,
                    "website": hospital.website,
                    "latitude": hospital.latitude,
                    "longitude": hospital.longitude,
                    "distance": {
                        "km": round(distance_result.distance_km, 2),
                        "miles": round(distance_result.distance_miles, 2),
                        "travel_time_minutes": distance_result.estimated_travel_time_minutes
                    }
                }
                nearby_hospitals.append(hospital_info)
        
        # Sort by distance
        nearby_hospitals.sort(key=lambda x: x["distance"]["km"])
        return nearby_hospitals
    
    def get_hospital_organ_availability(self, hospital_id: int) -> Dict:
        """
        Get all available organs at a specific hospital
        """
        hospital = self.db.query(Hospital).filter(Hospital.id == hospital_id).first()
        if not hospital:
            return {"error": "Hospital not found"}
        
        availabilities = self.db.query(OrganAvailability).filter(
            OrganAvailability.hospital_id == hospital_id,
            OrganAvailability.is_available == True
        ).join(Organ).all()
        
        hospital_info = {
            "id": hospital.id,
            "name": hospital.name,
            "address": hospital.address,
            "city": hospital.city,
            "state": hospital.state,
            "phone": hospital.phone,
            "email": hospital.email,
            "website": hospital.website,
            "latitude": hospital.latitude,
            "longitude": hospital.longitude
        }
        
        available_organs = []
        for availability in availabilities:
            organ_info = {
                "organ": {
                    "id": availability.organ.id,
                    "name": availability.organ.name,
                    "description": availability.organ.description,
                    "urgency_level": availability.organ.urgency_level,
                    "preservation_time_hours": availability.organ.preservation_time_hours
                },
                "availability": {
                    "id": availability.id,
                    "quantity": availability.quantity,
                    "blood_type": availability.blood_type,
                    "age_range": availability.age_range,
                    "condition": availability.condition,
                    "notes": availability.notes,
                    "last_updated": availability.last_updated.isoformat()
                }
            }
            available_organs.append(organ_info)
        
        return {
            "hospital": hospital_info,
            "available_organs": available_organs,
            "total_organs": len(available_organs)
        }
    
    def create_patient_request(self, 
                             patient_name: str,
                             patient_age: int,
                             blood_type: str,
                             organ_name: str,
                             user_latitude: float,
                             user_longitude: float,
                             contact_phone: str = None,
                             contact_email: str = None,
                             medical_notes: str = None,
                             urgency_level: int = 1) -> Dict:
        """
        Create a new patient request for organ transplant
        """
        # Find organ by name
        organ = self.db.query(Organ).filter(Organ.name.ilike(f"%{organ_name}%")).first()
        if not organ:
            return {"error": f"Organ '{organ_name}' not found"}
        
        # Create patient request
        patient_request = PatientRequest(
            patient_name=patient_name,
            patient_age=patient_age,
            blood_type=blood_type,
            organ_id=organ.id,
            urgency_level=urgency_level,
            location_latitude=user_latitude,
            location_longitude=user_longitude,
            contact_phone=contact_phone,
            contact_email=contact_email,
            medical_notes=medical_notes,
            status="pending"
        )
        
        self.db.add(patient_request)
        self.db.commit()
        
        # Find matching hospitals
        matching_hospitals = self.search_organs_by_location(
            user_latitude, user_longitude, organ_name, blood_type, 500.0, urgency_level
        )
        
        # Save search results
        for match in matching_hospitals[:10]:  # Top 10 matches
            search_result = SearchResult(
                patient_request_id=patient_request.id,
                hospital_id=match["hospital"]["id"],
                distance_km=match["distance"]["km"],
                estimated_travel_time_minutes=match["distance"]["travel_time_minutes"],
                organ_availability_id=match["availability"]["id"],
                match_score=match["compatibility_score"]
            )
            self.db.add(search_result)
        
        self.db.commit()
        
        return {
            "patient_request_id": patient_request.id,
            "status": "created",
            "matching_hospitals": len(matching_hospitals),
            "top_matches": matching_hospitals[:5]  # Top 5 matches
        }
    
    def _calculate_compatibility_score(self, 
                                  availability: OrganAvailability, 
                                  user_blood_type: str = None,
                                  urgency_level: int = None) -> float:
        """Calculate compatibility score between user and organ availability"""
        score = 0.5  # Base score
        
        # Blood type compatibility
        if user_blood_type and availability.blood_type:
            if user_blood_type == availability.blood_type:
                score += 0.3
            elif self._is_blood_type_compatible(user_blood_type, availability.blood_type):
                score += 0.2
        
        # Organ condition
        condition_scores = {
            "excellent": 0.2,
            "good": 0.1,
            "fair": 0.05
        }
        score += condition_scores.get(availability.condition, 0)
        
        # Urgency level match
        if urgency_level and availability.organ.urgency_level:
            if availability.organ.urgency_level >= urgency_level:
                score += 0.1
        
        return min(score, 1.0)
    
    def _calculate_priority_score(self, 
                               distance_km: float, 
                               compatibility_score: float, 
                               urgency_level: int) -> float:
        """Calculate overall priority score for ranking results"""
        # Distance factor (closer is better)
        distance_factor = max(0, 1 - (distance_km / 500))  # Normalize to 0-1
        
        # Urgency factor (higher urgency gets priority)
        urgency_factor = urgency_level / 4.0  # Normalize to 0-1
        
        # Combined score
        priority_score = (
            compatibility_score * 0.4 +  # 40% compatibility
            distance_factor * 0.3 +      # 30% distance
            urgency_factor * 0.3         # 30% urgency
        )
        
        return priority_score
    
    def _is_blood_type_compatible(self, recipient: str, donor: str) -> bool:
        """Check if blood types are compatible"""
        compatible_pairs = {
            "O-": ["O-"],
            "O+": ["O-", "O+"],
            "A-": ["O-", "A-"],
            "A+": ["O-", "O+", "A-", "A+"],
            "B-": ["O-", "B-"],
            "B+": ["O-", "O+", "B-", "B+"],
            "AB-": ["O-", "A-", "B-", "AB-"],
            "AB+": ["O-", "O+", "A-", "A+", "B-", "B+", "AB-", "AB+"]
        }
        
        return donor in compatible_pairs.get(recipient, [])

