#!/usr/bin/env python3
"""
Organ Donation Project - System Verification Script
This script verifies that all components are working correctly
"""

import os
import sys
import subprocess
from pathlib import Path

def print_header():
    """Print verification header"""
    print("=" * 60)
    print("🏥 ORGAN DONATION PROJECT - SYSTEM VERIFICATION 🏥")
    print("=" * 60)
    print()

def check_python_version():
    """Check Python version"""
    print("🐍 Checking Python version...")
    version = sys.version_info
    if version.major >= 3 and version.minor >= 8:
        print(f"✅ Python {version.major}.{version.minor}.{version.micro} is compatible")
        return True
    else:
        print(f"❌ Python {version.major}.{version.minor}.{version.micro} is not compatible")
        print("   Python 3.8+ is required")
        return False

def check_required_files():
    """Check if all required files exist"""
    print("\n📁 Checking required files...")
    
    required_files = [
        "main.py",
        "database.py", 
        "models.py",
        "geolocation.py",
        "search_service.py",
        "routing_service.py",
        "requirements.txt",
        "run_system.py",
        "setup.py",
        "test_system.py",
        "frontend/index.html",
        "frontend/app.js",
        "README.md",
        "start.bat",
        "start.sh"
    ]
    
    missing_files = []
    for file_path in required_files:
        if not Path(file_path).exists():
            missing_files.append(file_path)
        else:
            print(f"✅ {file_path}")
    
    if missing_files:
        print(f"\n❌ Missing files: {missing_files}")
        return False
    
    print(f"\n✅ All {len(required_files)} required files found")
    return True

def check_dependencies():
    """Check if dependencies can be imported"""
    print("\n📦 Checking dependencies...")
    
    dependencies = [
        "fastapi",
        "uvicorn", 
        "sqlalchemy",
        "pandas",
        "requests"
    ]
    
    missing_deps = []
    for dep in dependencies:
        try:
            __import__(dep)
            print(f"✅ {dep}")
        except ImportError:
            missing_deps.append(dep)
            print(f"❌ {dep}")
    
    if missing_deps:
        print(f"\n⚠️  Missing dependencies: {missing_deps}")
        print("   Run: pip install -r requirements.txt")
        return False
    
    print(f"\n✅ All {len(dependencies)} dependencies available")
    return True

def check_database():
    """Check database initialization"""
    print("\n🗄️  Checking database...")
    
    try:
        from database import create_tables, init_sample_data
        print("✅ Database module imported successfully")
        
        # Check if database file exists
        if Path("organ_transplant.db").exists():
            print("✅ Database file exists")
        else:
            print("⚠️  Database file not found (will be created on first run)")
        
        return True
    except Exception as e:
        print(f"❌ Database check failed: {e}")
        return False

def check_frontend():
    """Check frontend files"""
    print("\n🌐 Checking frontend...")
    
    frontend_files = [
        "frontend/index.html",
        "frontend/app.js"
    ]
    
    for file_path in frontend_files:
        if Path(file_path).exists():
            print(f"✅ {file_path}")
        else:
            print(f"❌ {file_path}")
            return False
    
    print("✅ Frontend files ready")
    return True

def check_documentation():
    """Check documentation files"""
    print("\n📚 Checking documentation...")
    
    doc_files = [
        "README.md",
        "INSTALLATION_GUIDE.md",
        "FEATURES.md", 
        "QUICK_START.md",
        "PROJECT_SUMMARY.md"
    ]
    
    for file_path in doc_files:
        if Path(file_path).exists():
            print(f"✅ {file_path}")
        else:
            print(f"❌ {file_path}")
            return False
    
    print("✅ Documentation complete")
    return True

def check_startup_scripts():
    """Check startup scripts"""
    print("\n🚀 Checking startup scripts...")
    
    scripts = [
        "start.bat",
        "start.sh",
        "start_system.bat", 
        "start_system.sh"
    ]
    
    for script in scripts:
        if Path(script).exists():
            print(f"✅ {script}")
        else:
            print(f"❌ {script}")
            return False
    
    print("✅ Startup scripts ready")
    return True

def run_quick_test():
    """Run a quick system test"""
    print("\n🧪 Running quick system test...")
    
    try:
        # Test database initialization
        from database import create_tables, init_sample_data
        print("✅ Database functions available")
        
        # Test model imports
        from models import Hospital, Organ, OrganAvailability
        print("✅ Database models available")
        
        # Test service imports
        from geolocation import GeolocationService
        from search_service import OrganSearchService
        print("✅ Service modules available")
        
        print("✅ Quick test passed")
        return True
    except Exception as e:
        print(f"❌ Quick test failed: {e}")
        return False

def print_summary(results):
    """Print verification summary"""
    print("\n" + "=" * 60)
    print("📊 VERIFICATION SUMMARY")
    print("=" * 60)
    
    total_checks = len(results)
    passed_checks = sum(results.values())
    
    print(f"Total Checks: {total_checks}")
    print(f"Passed: {passed_checks}")
    print(f"Failed: {total_checks - passed_checks}")
    
    if passed_checks == total_checks:
        print("\n🎉 ALL CHECKS PASSED!")
        print("✅ System is ready to use")
        print("\n🚀 Next Steps:")
        print("   1. Run: python setup.py (one-time setup)")
        print("   2. Run: python run_system.py (start system)")
        print("   3. Open: http://localhost:8001 (in browser)")
        print("   4. Start saving lives! 🫀❤️")
    else:
        print("\n⚠️  SOME CHECKS FAILED")
        print("❌ System may not work correctly")
        print("\n🔧 Troubleshooting:")
        print("   1. Install missing dependencies")
        print("   2. Check file permissions")
        print("   3. Run setup script again")
        print("   4. Check error messages above")
    
    print("\n" + "=" * 60)

def main():
    """Main verification function"""
    print_header()
    
    # Run all checks
    results = {
        "Python Version": check_python_version(),
        "Required Files": check_required_files(),
        "Dependencies": check_dependencies(),
        "Database": check_database(),
        "Frontend": check_frontend(),
        "Documentation": check_documentation(),
        "Startup Scripts": check_startup_scripts(),
        "Quick Test": run_quick_test()
    }
    
    # Print summary
    print_summary(results)
    
    # Return success status
    return all(results.values())

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
