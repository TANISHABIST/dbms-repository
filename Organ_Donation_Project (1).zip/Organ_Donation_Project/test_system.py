#!/usr/bin/env python3
"""
Test script for the Organ Transplant Database & Hospital Locator System
"""

import requests
import json
import time
import sys
from pathlib import Path

def test_api_connection():
    """Test if the API is running and accessible"""
    print("🔍 Testing API connection...")
    
    try:
        response = requests.get("http://localhost:8000/health", timeout=5)
        if response.status_code == 200:
            print("✅ API is running and accessible")
            return True
        else:
            print(f"❌ API returned status code: {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        print(f"❌ API connection failed: {e}")
        return False

def test_hospitals_endpoint():
    """Test the hospitals endpoint"""
    print("\n🏥 Testing hospitals endpoint...")
    
    try:
        response = requests.get("http://localhost:8000/hospitals", timeout=10)
        if response.status_code == 200:
            hospitals = response.json()
            print(f"✅ Found {len(hospitals)} hospitals")
            
            # Display first few hospitals
            for i, hospital in enumerate(hospitals[:3]):
                print(f"   {i+1}. {hospital['name']} - {hospital['city']}, {hospital['state']}")
            
            return True
        else:
            print(f"❌ Hospitals endpoint failed: {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        print(f"❌ Hospitals endpoint error: {e}")
        return False

def test_organs_endpoint():
    """Test the organs endpoint"""
    print("\n🫀 Testing organs endpoint...")
    
    try:
        response = requests.get("http://localhost:8000/organs", timeout=10)
        if response.status_code == 200:
            organs = response.json()
            print(f"✅ Found {len(organs)} organ types")
            
            # Display organs
            for organ in organs:
                print(f"   • {organ['name']} (Urgency: {organ['urgency_level']})")
            
            return True
        else:
            print(f"❌ Organs endpoint failed: {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        print(f"❌ Organs endpoint error: {e}")
        return False

def test_search_organs():
    """Test the organ search functionality"""
    print("\n🔍 Testing organ search...")
    
    # Test search parameters (Delhi coordinates)
    params = {
        'latitude': 28.6139,
        'longitude': 77.2090,
        'organ_name': 'Heart',
        'max_distance_km': 500
    }
    
    try:
        response = requests.get("http://localhost:8000/search/organs", params=params, timeout=10)
        if response.status_code == 200:
            results = response.json()
            print(f"✅ Found {len(results)} heart transplant options")
            
            if results:
                for i, result in enumerate(results[:2]):
                    print(f"   {i+1}. {result['hospital']['name']} - {result['distance']['km']} km")
            
            return True
        else:
            print(f"❌ Organ search failed: {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        print(f"❌ Organ search error: {e}")
        return False

def test_nearest_hospitals():
    """Test the nearest hospitals search"""
    print("\n🏥 Testing nearest hospitals search...")
    
    # Test search parameters (Delhi coordinates)
    params = {
        'latitude': 28.6139,
        'longitude': 77.2090,
        'max_distance_km': 100
    }
    
    try:
        response = requests.get("http://localhost:8000/search/nearest-hospitals", params=params, timeout=10)
        if response.status_code == 200:
            results = response.json()
            print(f"✅ Found {len(results)} nearby hospitals")
            
            if results:
                for i, result in enumerate(results[:3]):
                    print(f"   {i+1}. {result['name']} - {result['distance']['km']} km")
            
            return True
        else:
            print(f"❌ Nearest hospitals search failed: {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        print(f"❌ Nearest hospitals search error: {e}")
        return False

def test_patient_request():
    """Test patient request submission"""
    print("\n👤 Testing patient request submission...")
    
    request_data = {
        'patient_name': 'Test Patient',
        'patient_age': 45,
        'blood_type': 'O+',
        'organ_name': 'Heart',
        'latitude': 28.6139,
        'longitude': 77.2090,
        'contact_phone': '+91-9876543210',
        'contact_email': 'test@example.com',
        'medical_notes': 'Test request for system validation',
        'urgency_level': 2
    }
    
    try:
        response = requests.post(
            "http://localhost:8000/patient-request",
            json=request_data,
            timeout=10
        )
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Patient request submitted successfully!")
            print(f"   Request ID: {result.get('patient_request_id', 'N/A')}")
            print(f"   Matching hospitals: {result.get('matching_hospitals', 0)}")
            return True
        else:
            print(f"❌ Patient request failed: {response.status_code}")
            print(f"Response: {response.text}")
            return False
    except requests.exceptions.RequestException as e:
        print(f"❌ Patient request error: {e}")
        return False

def test_distance_calculation():
    """Test distance calculation"""
    print("\n📏 Testing distance calculation...")
    
    # Test distance between Delhi and Mumbai
    params = {
        'lat1': 28.6139,
        'lon1': 77.2090,
        'lat2': 19.0760,
        'lon2': 72.8777
    }
    
    try:
        response = requests.get("http://localhost:8000/calculate-distance", params=params, timeout=10)
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Distance calculated successfully!")
            print(f"   Distance: {result['distance_km']} km")
            print(f"   Travel time: {result['estimated_travel_time_minutes']} minutes")
            return True
        else:
            print(f"❌ Distance calculation failed: {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        print(f"❌ Distance calculation error: {e}")
        return False

def test_statistics():
    """Test system statistics"""
    print("\n📊 Testing system statistics...")
    
    try:
        response = requests.get("http://localhost:8000/stats", timeout=10)
        if response.status_code == 200:
            stats = response.json()
            print(f"✅ System statistics retrieved!")
            print(f"   Total hospitals: {stats['total_hospitals']}")
            print(f"   Total organs: {stats['total_organs']}")
            print(f"   Available organs: {stats['available_organs']}")
            print(f"   Total requests: {stats['total_requests']}")
            return True
        else:
            print(f"❌ Statistics endpoint failed: {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        print(f"❌ Statistics endpoint error: {e}")
        return False

def run_all_tests():
    """Run all system tests"""
    print("🧪 Starting Organ Transplant System Tests")
    print("=" * 50)
    
    tests = [
        ("API Connection", test_api_connection),
        ("Hospitals Endpoint", test_hospitals_endpoint),
        ("Organs Endpoint", test_organs_endpoint),
        ("Organ Search", test_search_organs),
        ("Nearest Hospitals", test_nearest_hospitals),
        ("Patient Request", test_patient_request),
        ("Distance Calculation", test_distance_calculation),
        ("System Statistics", test_statistics)
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        print(f"\n{'='*20} {test_name} {'='*20}")
        try:
            if test_func():
                passed += 1
                print(f"✅ {test_name} PASSED")
            else:
                print(f"❌ {test_name} FAILED")
        except Exception as e:
            print(f"❌ {test_name} ERROR: {e}")
    
    print("\n" + "=" * 50)
    print(f"📊 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! System is working correctly.")
        return True
    else:
        print("⚠️  Some tests failed. Please check the error messages.")
        return False

def main():
    """Main test function"""
    print("🏥 Organ Transplant Database & Hospital Locator System")
    print("🧪 System Test Suite")
    print("=" * 60)
    
    # Check if API is running
    print("⏳ Waiting for API to be ready...")
    time.sleep(2)
    
    if not test_api_connection():
        print("\n❌ API is not running. Please start the system first:")
        print("   python run_system.py")
        sys.exit(1)
    
    # Run all tests
    success = run_all_tests()
    
    if success:
        print("\n🎉 System is fully functional and ready for use!")
        print("🌐 Open http://localhost:8001 in your browser to use the system.")
    else:
        print("\n⚠️  Some issues were found. Please check the error messages above.")
        sys.exit(1)

if __name__ == "__main__":
    main()

