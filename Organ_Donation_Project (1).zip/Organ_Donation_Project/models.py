from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()

class Hospital(Base):
    """Hospital model with location and organ transplant capabilities"""
    __tablename__ = "hospitals"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    address = Column(Text, nullable=False)
    city = Column(String(100), nullable=False)
    state = Column(String(100), nullable=False)
    country = Column(String(100), default="India")
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    phone = Column(String(20))
    email = Column(String(100))
    website = Column(String(200))
    is_transplant_center = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    organ_availability = relationship("OrganAvailability", back_populates="hospital")
    transplant_programs = relationship("TransplantProgram", back_populates="hospital")

class Organ(Base):
    """Organ types available for transplant"""
    __tablename__ = "organs"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False, unique=True)
    description = Column(Text)
    urgency_level = Column(Integer, default=1)  # 1=low, 2=medium, 3=high, 4=critical
    preservation_time_hours = Column(Integer)  # How long organ can be preserved
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    availability = relationship("OrganAvailability", back_populates="organ")
    transplant_programs = relationship("TransplantProgram", back_populates="organ")

class OrganAvailability(Base):
    """Current availability of organs at hospitals"""
    __tablename__ = "organ_availability"
    
    id = Column(Integer, primary_key=True, index=True)
    hospital_id = Column(Integer, ForeignKey("hospitals.id"), nullable=False)
    organ_id = Column(Integer, ForeignKey("organs.id"), nullable=False)
    is_available = Column(Boolean, default=False)
    quantity = Column(Integer, default=0)
    blood_type = Column(String(10))  # A+, B-, O+, etc.
    age_range = Column(String(20))  # e.g., "18-65", "pediatric"
    condition = Column(String(100))  # e.g., "excellent", "good", "fair"
    notes = Column(Text)
    last_updated = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    hospital = relationship("Hospital", back_populates="organ_availability")
    organ = relationship("Organ", back_populates="availability")

class TransplantProgram(Base):
    """Transplant programs offered by hospitals"""
    __tablename__ = "transplant_programs"
    
    id = Column(Integer, primary_key=True, index=True)
    hospital_id = Column(Integer, ForeignKey("hospitals.id"), nullable=False)
    organ_id = Column(Integer, ForeignKey("organs.id"), nullable=False)
    program_name = Column(String(200), nullable=False)
    is_active = Column(Boolean, default=True)
    success_rate = Column(Float)  # Percentage success rate
    average_wait_time_days = Column(Integer)
    program_description = Column(Text)
    requirements = Column(Text)  # Patient requirements
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    hospital = relationship("Hospital", back_populates="transplant_programs")
    organ = relationship("Organ", back_populates="transplant_programs")

class PatientRequest(Base):
    """Patient requests for organ transplants"""
    __tablename__ = "patient_requests"
    
    id = Column(Integer, primary_key=True, index=True)
    patient_name = Column(String(200), nullable=False)
    patient_age = Column(Integer, nullable=False)
    blood_type = Column(String(10), nullable=False)
    organ_id = Column(Integer, ForeignKey("organs.id"), nullable=False)
    urgency_level = Column(Integer, default=1)
    location_latitude = Column(Float, nullable=False)
    location_longitude = Column(Float, nullable=False)
    contact_phone = Column(String(20))
    contact_email = Column(String(100))
    medical_notes = Column(Text)
    status = Column(String(50), default="pending")  # pending, matched, completed, cancelled
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    organ = relationship("Organ")

class SearchResult(Base):
    """Search results for organ availability"""
    __tablename__ = "search_results"
    
    id = Column(Integer, primary_key=True, index=True)
    patient_request_id = Column(Integer, ForeignKey("patient_requests.id"))
    hospital_id = Column(Integer, ForeignKey("hospitals.id"))
    distance_km = Column(Float, nullable=False)
    estimated_travel_time_minutes = Column(Integer)
    organ_availability_id = Column(Integer, ForeignKey("organ_availability.id"))
    match_score = Column(Float)  # Compatibility score
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    patient_request = relationship("PatientRequest")
    hospital = relationship("Hospital")
    organ_availability = relationship("OrganAvailability")

