#!/bin/bash
echo "Starting Organ Transplant Database System..."
python3 run_system.py
