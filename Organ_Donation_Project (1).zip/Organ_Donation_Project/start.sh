#!/bin/bash

# Organ Donation Project - Start Script
# This script starts the complete organ donation system

echo ""
echo "================================================================"
echo "           🏥 ORGAN DONATION PROJECT - STARTING SYSTEM 🏥"
echo "================================================================"
echo ""
echo "Initializing Organ Transplant Database & Hospital Locator..."
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 is not installed"
    echo "Please install Python 3.8+ from https://python.org"
    exit 1
fi

echo "✅ Python3 found"
echo ""

# Install dependencies if needed
echo "📦 Checking dependencies..."
pip3 install -r requirements.txt > /dev/null 2>&1

# Start the system
echo "🚀 Starting Organ Donation System..."
echo ""
echo "⏳ Please wait while the system initializes..."
echo ""

python3 run_system.py

echo ""
echo "================================================================"
echo "                    SYSTEM STOPPED"
echo "================================================================"
echo ""
