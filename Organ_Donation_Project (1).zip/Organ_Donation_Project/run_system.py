#!/usr/bin/env python3
"""
Organ Transplant Database & Hospital Locator System
Startup script to initialize and run the complete system
"""

import os
import sys
import subprocess
import time
import webbrowser
from pathlib import Path

def print_banner():
    """Print system banner"""
    banner = """
    ╔══════════════════════════════════════════════════════════════╗
    ║                                                              ║
    ║        🏥 ORGAN TRANSPLANT DATABASE & HOSPITAL LOCATOR 🏥     ║
    ║                                                              ║
    ║              A Life-Saving Technology Platform               ║
    ║                                                              ║
    ╚══════════════════════════════════════════════════════════════╝
    """
    print(banner)

def check_dependencies():
    """Check if required dependencies are installed"""
    print("🔍 Checking dependencies...")
    
    required_packages = [
        'fastapi',
        'uvicorn',
        'sqlalchemy',
        'pandas',
        'requests'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
            print(f"✅ {package}")
        except ImportError:
            missing_packages.append(package)
            print(f"❌ {package}")
    
    if missing_packages:
        print(f"\n⚠️  Missing packages: {', '.join(missing_packages)}")
        print("Installing missing packages...")
        
        try:
            subprocess.check_call([sys.executable, '-m', 'pip', 'install'] + missing_packages)
            print("✅ All packages installed successfully!")
        except subprocess.CalledProcessError:
            print("❌ Failed to install packages. Please install manually:")
            print(f"pip install {' '.join(missing_packages)}")
            return False
    
    return True

def initialize_database():
    """Initialize the database with sample data"""
    print("\n🗄️  Initializing database...")
    
    try:
        from database import create_tables, init_sample_data
        create_tables()
        init_sample_data()
        print("✅ Database initialized successfully!")
        return True
    except Exception as e:
        print(f"❌ Database initialization failed: {e}")
        return False

def start_backend():
    """Start the FastAPI backend server"""
    print("\n🚀 Starting backend server...")
    
    try:
        # Start the server in a subprocess
        process = subprocess.Popen([
            sys.executable, 'main.py'
        ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        # Wait a moment for the server to start
        time.sleep(3)
        
        # Check if the server is running
        if process.poll() is None:
            print("✅ Backend server started successfully!")
            print("🌐 API available at: http://localhost:8000")
            print("📚 API documentation: http://localhost:8000/docs")
            return process
        else:
            stdout, stderr = process.communicate()
            print(f"❌ Backend server failed to start:")
            print(f"STDOUT: {stdout.decode()}")
            print(f"STDERR: {stderr.decode()}")
            return None
            
    except Exception as e:
        print(f"❌ Failed to start backend server: {e}")
        return None

def start_frontend():
    """Start the frontend web server"""
    print("\n🌐 Starting frontend server...")
    
    try:
        # Start a simple HTTP server for the frontend
        frontend_dir = Path(__file__).parent / 'frontend'
        os.chdir(frontend_dir)
        
        process = subprocess.Popen([
            sys.executable, '-m', 'http.server', '8001'
        ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        time.sleep(2)
        
        if process.poll() is None:
            print("✅ Frontend server started successfully!")
            print("🌐 Frontend available at: http://localhost:8001")
            return process
        else:
            stdout, stderr = process.communicate()
            print(f"❌ Frontend server failed to start:")
            print(f"STDOUT: {stdout.decode()}")
            print(f"STDERR: {stderr.decode()}")
            return None
            
    except Exception as e:
        print(f"❌ Failed to start frontend server: {e}")
        return None

def open_browser():
    """Open the web browser to the frontend"""
    print("\n🌐 Opening web browser...")
    
    try:
        webbrowser.open('http://localhost:8001')
        print("✅ Browser opened successfully!")
    except Exception as e:
        print(f"⚠️  Could not open browser automatically: {e}")
        print("Please manually open: http://localhost:8001")

def print_system_info():
    """Print system information and usage instructions"""
    print("\n" + "="*60)
    print("🎉 SYSTEM SUCCESSFULLY STARTED!")
    print("="*60)
    print("\n📋 System Information:")
    print("   • Backend API: http://localhost:8000")
    print("   • Frontend UI: http://localhost:8001")
    print("   • API Docs: http://localhost:8000/docs")
    print("   • Database: SQLite (organ_transplant.db)")
    
    print("\n🔧 Available Features:")
    print("   • Search for organs by type and location")
    print("   • Find nearest hospitals with transplant services")
    print("   • GPS navigation and routing")
    print("   • Patient request submission")
    print("   • Interactive map with hospital markers")
    print("   • Real-time organ availability")
    
    print("\n📱 How to Use:")
    print("   1. Open http://localhost:8001 in your browser")
    print("   2. Allow location access when prompted")
    print("   3. Search for organs or hospitals")
    print("   4. View results on the interactive map")
    print("   5. Get directions to selected hospitals")
    
    print("\n🛑 To Stop the System:")
    print("   • Press Ctrl+C in this terminal")
    print("   • Or close this terminal window")
    
    print("\n📞 Support:")
    print("   • Check the README.md for detailed documentation")
    print("   • View API documentation at /docs")
    print("   • Check console for error messages")
    
    print("\n" + "="*60)

def main():
    """Main startup function"""
    print_banner()
    
    # Check dependencies
    if not check_dependencies():
        print("\n❌ Dependency check failed. Please install required packages.")
        return
    
    # Initialize database
    if not initialize_database():
        print("\n❌ Database initialization failed. Please check the error messages.")
        return
    
    # Start backend server
    backend_process = start_backend()
    if not backend_process:
        print("\n❌ Failed to start backend server.")
        return
    
    # Start frontend server
    frontend_process = start_frontend()
    if not frontend_process:
        print("\n❌ Failed to start frontend server.")
        backend_process.terminate()
        return
    
    # Open browser
    open_browser()
    
    # Print system information
    print_system_info()
    
    try:
        # Keep the script running
        print("\n⏳ System is running... Press Ctrl+C to stop.")
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n\n🛑 Stopping system...")
        
        # Terminate processes
        if backend_process:
            backend_process.terminate()
            print("✅ Backend server stopped")
        
        if frontend_process:
            frontend_process.terminate()
            print("✅ Frontend server stopped")
        
        print("👋 System stopped successfully!")

if __name__ == "__main__":
    main()

